jQuery( document ).ready( function(){
	
	//hide remove field icon
	if(jQuery('.fee-setting-wrapper').length) {
		if(jQuery('.fee-table tbody tr').length <= 1) {
			jQuery('.fee-table tbody tr .dashicons-remove').hide();
		}
	}
	
	//add fee fields
	jQuery('body').on('click', '.add-remove-field .dashicons-insert', function() {
		var current_tr = jQuery(this).closest('tr');
		
		jQuery.ajax({
			type: 'POST',
			url: my_ajaxurl.ajax_url,
			data: {
				action: 'add_fee_field',
			},
			success: function(response){				
				jQuery(current_tr).after(response);
				jQuery('.dashicons-remove').show();
			},
			error: function(response){
				console.log(response);
			},
		});
	});
	
	//remove fee fields
	jQuery('body').on('click', '.add-remove-field .dashicons-remove', function() {
		var $this = jQuery(this).closest('tr');
		var id = $this.find('.groupid').val();
		
		//delete fee data			
		jQuery.ajax({
			type: 'POST',
			url: my_ajaxurl.ajax_url,
			data: {
				action: 'delete_fee_data',
				id: id,
			},
			success: function(response){
				console.log(response);				
				if(response == 'true') {
					jQuery('.fee-upd-sucs-del').show(0).delay(3000).hide(1000);
					$this.remove();
				} else {
					jQuery('.fee-upd-fail-del').show(0).delay(3000).hide(1000);
				}
			},
			error: function(response){
				console.log(response);
			},
		});
		
		if(jQuery('.fee-table tbody tr').length <= 1) {
			jQuery('.dashicons-remove').hide();
		}
	});
	
	//save fee data
	jQuery('body').on('click', '.save-fee', function() {
		
		var $save = jQuery(this);
		var $this = jQuery(this).closest('tr');
		var fee_data = {};
	
		fee_data[$this.find('.groupid').attr('name')] = $this.find('.groupid').val();
		fee_data[$this.find('.agegroup').attr('name')] = $this.find('.agegroup').val();
		fee_data[$this.find('.monthly').attr('name')] = $this.find('.monthly').val();
		fee_data[$this.find('.fullsummer').attr('name')] = $this.find('.fullsummer').val();
		fee_data[$this.find('.guest').attr('name')] = $this.find('.guest').val();
		
		//add fee data				
		jQuery.ajax({
			type: 'POST',
			url: my_ajaxurl.ajax_url,
			data: {
				action: 'add_fee_data',
				fee_data: fee_data,
			},
			success: function(response){
				//console.log(response);				
				if(response == 'true') {
					jQuery('.fee-upd-sucs').show(0).delay(3000).hide(1000);
					$save.text('Update');
				} else {
					jQuery('.fee-upd-fail').show(0).delay(3000).hide(1000);
				}
			},
			error: function(response){
				console.log(response);
			},
		});
	});
	
	//save stripe data
	jQuery('.wl-stripe-save-btn').click(function() {

		var tpbkey = jQuery('.wl-stripe-test-pbkey').val();
		var tpvtkey = jQuery('.wl-stripe-test-pvtkey').val();
		var lpbkey = jQuery('.wl-stripe-live-pbkey').val();
		var lpvtkey = jQuery('.wl-stripe-live-pvtkey').val();
		var stripekey = jQuery('.keytype').val();
		
		/*store category questions*/
		jQuery.ajax({
			type: 'POST',
			url: my_ajaxurl.ajax_url,
			data: {
				action: 'insert_stripedata',
				tpbkey: tpbkey,
				tpvtkey: tpvtkey,
				lpbkey: lpbkey,
				lpvtkey: lpvtkey,
				stripekey: stripekey,
			},
			success: function(response){
				//console.log(response);
				if(response == 1) {
					jQuery('.wl-upd-sucs').show(0).delay(3000).hide(1000);
				} else {
					jQuery('.wl-upd-fail').show(0).delay(3000).hide(1000);
				}				
			},
			error: function(response){
				console.log(response);
			},
		});
	});
})