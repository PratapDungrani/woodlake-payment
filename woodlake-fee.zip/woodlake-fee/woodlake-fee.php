<?php
/**
 * Plugin Name: Woodlake Tuition Fee
 * Description: Add user friendly payment gateway to receive payments from client.
 * Plugin URI: 
 * Author: Pratap Dungrani
 * Author URI: 
 * Version: 1.0
 *
 * Text Domain: woodlake-fee
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * Define Plugin URL and Directory Path
 */
global $wpdb;
define('WOODLAKE_FEE_URL', plugins_url('/', __FILE__));  // Define Plugin URL
define('WOODLAKE_FEE_PATH', plugin_dir_path(__FILE__));  // Define Plugin Directory Path
define('WOODLAKE_FEE', 'woodlake-fee');

define('WOODLAKE_FEE_TBL', $wpdb->prefix . 'woodlake_fee' );
define('WOODLAKE_CUSTOMER_TBL', $wpdb->prefix . 'woodlake_customer' );

require_once WOODLAKE_FEE_PATH . 'woodlake/payment-shortcode.php';
require_once WOODLAKE_FEE_PATH . 'includes/woodlake-stripe.php';
require_once WOODLAKE_FEE_PATH . 'includes/fee-table.php';

/*
 * Load profile card scripts and styles
 * @since v1.0.0
 */
 
function woodlake_admin_scripts() {
	wp_register_script('woodlake-script', WOODLAKE_FEE_URL . 'assets/js/custom.js', array('jquery'),false, true);
    wp_enqueue_script('woodlake-script');
	
	wp_register_style('woodlake-style', WOODLAKE_FEE_URL . 'assets/css/style.css', false);
	wp_enqueue_style('woodlake-style');
	
	wp_localize_script( 'woodlake-script', 'my_ajaxurl', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
}
add_action('admin_enqueue_scripts', 'woodlake_admin_scripts');


function woodlake_script_register() {
	
	wp_register_style('woodlake-page-style', WOODLAKE_FEE_URL . 'assets/css/user.css', false);
	wp_enqueue_style('experience-page-style');
	
	wp_register_script('woodlake-page-script', WOODLAKE_FEE_URL . 'assets/js/user.js', array('jquery'),false, true);
	wp_enqueue_script('woodlake-page-script');
	
	wp_localize_script( 'woodlake-script', 'my_ajaxurl', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	
}
add_action('wp_enqueue_scripts', 'woodlake_script_register');

/**
 * Fontawesome 5 support
 */
function fontawesome_5_support() {
    ?>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <?php
}
add_action('wp_head', 'fontawesome_5_support');

/**
 *
 * Create admin side pages
 */
function woodlake_admin_menu() {
	add_menu_page( __('Woodlake Fee', WOODLAKE_FEE), __('Woodlake Fee', WOODLAKE_FEE), 'manage_options', 'fee_table', 'fee_table');
	add_submenu_page( 'fee_table', __('Fee Table', WOODLAKE_FEE), __('Fee Table', WOODLAKE_FEE), 'manage_options', 'fee_table', 'fee_table' );
	add_submenu_page( 'fee_table', __('Stripe', WOODLAKE_FEE), __('Stripe', WOODLAKE_FEE), 'manage_options', 'stripe_settings', 'stripe_settings' );
}
add_action('admin_menu', 'woodlake_admin_menu');

/**
 *
 * Create required table
 */
function woodlake_create_table() {

	global $wpdb;
	
	// woodlake fee table
	if ( $wpdb->get_var('SHOW TABLES LIKE " . WOODLAKE_FEE_TBL . "') != WOODLAKE_FEE_TBL ) {
		$sql = "CREATE TABLE " . WOODLAKE_FEE_TBL . "(
			id int(11) NOT NULL AUTO_INCREMENT,
			age_group varchar(255) NOT NULL,
			monthly varchar(255) NOT NULL,
			full_summer varchar(255) NOT NULL,
			guest varchar(255) NOT NULL,
			created_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id))";
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
	
	// woodlake customer table
	if ( $wpdb->get_var('SHOW TABLES LIKE " . WOODLAKE_CUSTOMER_TBL . "') != WOODLAKE_CUSTOMER_TBL ) {
		$sql = "CREATE TABLE " . WOODLAKE_CUSTOMER_TBL . "(
			id int(11) NOT NULL AUTO_INCREMENT,
			customer_id varchar(255) NOT NULL,
			order_id varchar(255) NOT NULL,
			email varchar(255) NOT NULL,
			fname varchar(255) NOT NULL,
			lname varchar(255) NOT NULL,
			fee varchar(255) NOT NULL,
			address varchar(255) NOT NULL,
			country	varchar(255) NOT NULL,	
			city varchar(255) NOT NULL,
			state varchar(255) NOT NULL,
			zipcode varchar(255) NOT NULL,
			phone varchar(255) NOT NULL,
			created_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id))";
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
}
add_action('activate_plugin', 'woodlake_create_table');