<?php
//Include Stripe PHP library & set dynamic key
function stufftodo_stripe_key() {

	//include Stripe
	require_once( WOODLAKE_FEE_PATH . 'stripe-php/init.php');
	global $public_key, $secret_key;
	/*stripe payment mode key settings*/
	$stripedata = get_option('woodlake_stripekey');
	if(!empty($stripedata)) {
		$test_public_key = $stripedata['tpbkey'];
		$test_secret_key = $stripedata['tpvtkey'];
		$live_public_key = $stripedata['lpbkey'];
		$live_secret_key = $stripedata['lpvtkey'];
		$payment_mode_option = $stripedata['stripekey'];
		
		if($payment_mode_option == "live" ) {
			$public_key = $live_public_key;
			$secret_key = $live_secret_key;
		}else {
			$public_key = $test_public_key;
			$secret_key = $test_secret_key;
		}
	}
	
	//set api key
	$stripe = array(
	  "secret_key"      => $secret_key,
	  "publishable_key" => $public_key
	);

	\Stripe\Stripe::setApiKey($stripe['secret_key']);
	
}
add_action( 'init', 'stufftodo_stripe_key' );

/*
 * Woodlake payment shortcode
 */
function woodlake_payment_shortcode() {
	ob_start();	
	global $wpdb, $public_key, $secret_key;
	
	$results = $wpdb->get_results( "SELECT * FROM " . WOODLAKE_FEE_TBL);
	
	$month_fee = $wpdb->get_results("SELECT monthly FROM " . WOODLAKE_FEE_TBL);
	$summer_fee = $wpdb->get_results("SELECT full_summer FROM " . WOODLAKE_FEE_TBL);	
	$all_fees = array_merge($month_fee,$summer_fee);
	
	?>
	<style>
	.wl-fee-note{
		margin-bottom: 20px;
		font-weight: 600;
	}
	.wl-fee-pay-btn {
		font-size: 14px;
		letter-spacing: 0.5px;
		font-weight: 500;
		background-image: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
		display: inline-block;
		padding: 2px;
		cursor: pointer;
	}
	.wl-fee-btn {
		background-color: #fff;
		padding: 8px 30px;
	}
	.wl-fee-btn span {
		background-image: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;		
	}
	table {
		border: 1px solid #000;
		margin: 25px 0 !important;
	}
	th {
		border: none;
	}
	td {
		border-left: 0px;
		border-right: 0px;
		border-top: 1px solid #000;
		font-weight: 600;
	}
	tbody td:nth-child(1) {
		width: 35%;
	}
	
	.wl-stripe-popup {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: rgba(250, 250, 250, 1);
		z-index: 10000002;
		overflow-y: auto !important;
	}
	/* Hide scrollbar for Chrome, Safari and Opera */
	.wl-stripe-popup::-webkit-scrollbar {
		display: none;
	}
	/* Hide scrollbar for IE, Edge and Firefox */
	.wl-stripe-popup {
		-ms-overflow-style: none;  /* IE and Edge */
		scrollbar-width: none;  /* Firefox */
	}
	/* Chrome, Safari, Edge, Opera */
	input::-webkit-outer-spin-button,
	input::-webkit-inner-spin-button {
		-webkit-appearance: none;
		margin: 0;
	}
	/* Firefox */
	input[type=number] {
		-moz-appearance: textfield;
	}
	.wl-stripe-popup-sticky {
		position: -webkit-sticky; /* Safari */
		position: sticky;
		top: 0;
		box-shadow: 0px 5px 14px rgba(0, 0, 0, 0.1);
		background: rgba(255, 255, 255, 1);
		z-index: 1;
	}
	.wl-popup-close {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 65px;
		font-size: 18px;
		font-weight: 700;
	}
	.wl-checkout-close {
		position: absolute;	
		cursor: pointer;
		right: 75px;
	}
	.wl-payment-form-container {
		margin-top: 25px;
		display: flex;
		justify-content: center;
		height: 100%;
		overflow-y: auto !important;
	}
	.wl-payment-form-wrapper {
		margin-bottom: 100px;
	}
	.wl-email-wrapper, .wl-contribution-wrapper, .wl-payment-wrapper, .wl-review-wrapper {
		padding: 15px 20px;
		border: 1px solid #e3e3e3;
		background: rgba(255, 255, 255, 1);
	}
	.close-wrapper {
		margin-top: 25px;
	}
	.close-wrapper:not(.active) {
		height: 65px;
		overflow: hidden;		
	}
	.active {
		height: auto !important;
	}
	.wl-pydetail-title {
		font-size: 18px;
		font-weight: 700;
		position: relative;
		display: flex;
		align-items: center;
	}
	.edit-form {
		font-size: 12px;
		font-weight: 500;
		color: #aaa;
		position: absolute;
		right: 10px;
		cursor: pointer;
		display: none;
	}
	.wl-email-input, .wl-contribution-input, .wl-payment-input {
		margin: 15px 0;
	}
	.wl-email-input input, .wl-payment-wrapper input, #card-element, #country {
		width: 100%;
		border-radius: 5px;
		border: 1px solid #e3e3e3;
	}
	.wl-note-info {
		font-size: 12px;
	}
	.wl-cont-radio {
		margin-bottom: 5px;
	}
	.radio-container {
		display: inline;
		position: relative;
		padding-left: 25px;
		cursor: pointer;
		font-size: 14px;
		font-weight: 600;
		-webkit-user-select: none;
		-moz-user-select: none;
		-ms-user-select: none;
		user-select: none;
	}
	.radio-container input[type=radio] {
		position: absolute;
		opacity: 0;
		cursor: pointer;
	}
	.radio-checkmark {
		position: absolute;
		top: 0;
		left: 0;
		height: 20px;
		width: 20px;
		background-color: #eee;
		border-radius: 50%;
	}
	.radio-container:hover input ~ .radio-checkmark {
		background-color: #ccc;
	}
	.radio-container input:checked ~ .radio-checkmark {
		background-color: #eee;
	}
	.radio-checkmark:after {
		content: "";
		position: absolute;
		display: none;
	}
	.radio-container input:checked ~ .radio-checkmark:after {
		display: block;
	}
	.radio-container .radio-checkmark:after {
		top: 7px;
		left: 7px;
		width: 6px;
		height: 6px;
		border-radius: 50%;
		background: #000;
	}
	/*stripe field css*/
	.StripeElement {
		box-sizing: border-box;
		height: 40px;
		padding: 10px 12px;
		border: 1px solid transparent;
		border-radius: 4px;
		background-color: white;
		box-shadow: 0 1px 3px 0 #e6ebf1;
		-webkit-transition: box-shadow 150ms ease;
		transition: box-shadow 150ms ease;
	}
	.StripeElement--focus {
		box-shadow: 0 1px 3px 0 #cfd7df;
	}
	.StripeElement--invalid {
		border-color: #fa755a;
	}
	.StripeElement--webkit-autofill {
		background-color: #fefde5 !important;
	}
	#card-errors {
		color: red;
	}
	
	.wl-billing-title {
		font-size: 14px;
		font-weight: 500;
		margin-top: 10px;
	}
	.wl-billing-name {
		display: flex;
		justify-content: space-between;
	}
	.wl-billing-name div {
		width: 48%;
	}
	.field-space {
		margin-top: 10px;
	}
	.wl-payment-wrapper select {
		width: 100%;
	}
	.wl-billing-zcs {
		display: flex;
		justify-content: space-between;
	}
	.wl-billing-zcs div {
		width: 32%;
	}
	.wl-billing-error {
		font-size: 14px;
		color: #fff;
		display: flex;
		align-items: center;
		height: 45px;
		padding: 0 20px;
		background-color: #f44336;
		display: none;
	}
	
	.wl-payment-nextstep {
		width: 100%;
		height: 40px;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #fff;
		background: rgba(0, 0, 0, .8);
		border-radius: 4px;
		cursor: pointer;
	}
	.wl-payment-nextstep button {
		background: none;
		color: inherit;
		border: none;
		padding: 0;
		font: inherit;
		outline: inherit;
		width: inherit;
		height: inherit;
	}
	
	@media only screen and (min-width: 1900px) {
		.wl-payment-form-wrapper {
			width: 400px;
		}
	}
	@media only screen and (max-width: 1600px) {
		.wl-payment-form-wrapper {
			width: 25%;
		}
	}
	@media only screen and (max-width: 1024px) {
		.wl-payment-form-wrapper {
			width: 40%;
		}
		.wl-checkout-close {
			right: 50px;
		}
	}
	@media only screen and (max-width: 768px) {
		.wl-payment-form-wrapper {
			width: 50%;
		}
	}
	@media only screen and (max-width: 568px) {
		.wl-payment-form-wrapper {
			width: 70%;
		}
		.wl-checkout-title {
			width: 70%;
			line-height: initial;
			text-align: center;
		}
		.wl-checkout-close {
			right: 35px;
		}
	}
	@media only screen and (max-width: 414px) {
		.wl-payment-form-wrapper {
			width: 90%;
		}
		.wl-checkout-close {
			right: 25px;
		}
	}
	</style>
	
	<!--Fee table-->
	<div class="wl-fee-container">
		<div class="wl-fee-wrapper">
			<!--note-->
			<div class="wl-fee-note">Please see chart below to find the proper tuition payment for your child/children.</div>
			
			<!--pay button-->
			<div class="wl-fee-pay-btn">
				<div class="wl-fee-btn"><span>CLICK TO PAY</span></div>
			</div>
			
			<!--Fee table-->
			<div class="wl-fee-table-wrapper">
				<div class="wl-fee-table">
					<table>
						<thead>
							<tr>
								<th>AGE GROUP</th>
								<th>MONTHLY</th>
								<th>FULL SUMMER</th>
								<th>GUEST</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td>Daily/Weekly</td>
							</tr>
							<?php 
							if(!empty($results)) {
								foreach($results as $result) {
									$age_group = $result->age_group;
									$monthly = $result->monthly;
									$full_summer = $result->full_summer;
									$guest = $result->guest;
									?>
									<tr>
										<td><?php echo $age_group; ?></td>
										<td><?php echo $monthly; ?></td>
										<td><?php echo $full_summer; ?></td>
										<td><?php echo $guest; ?></td>
									</tr>
								<?php
								}
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
			
			<!--pay button-->
			<div class="wl-fee-pay-btn">
				<div class="wl-fee-btn"><span>CLICK TO PAY</span></div>
			</div>
		</div>
	</div>
	
	<script src="https://js.stripe.com/v3/"></script>
	<!--payment popup-->
	<div class="wl-stripe-popup">
		<div class="wl-stripe-wrapper">
			<!--close bar-->
			<div class="wl-stripe-popup-sticky">
				<div class="wl-popup-close">
					<div class="wl-checkout-title">Woodlake Village Day Camp: Woodlake Village Daycamp</div>
					<span class="wl-checkout-close"><img src="<?php echo WOODLAKE_FEE_URL . 'assets/images/icon-close-gray.svg'; ?>" alt="close" class=""></span>
				</div>
			</div>
			
			<!--payment form-->
			<form method="post" id="payment-form">
				<div class="wl-payment-form-container">
					<div class="wl-payment-form-wrapper">
						<!--Email container-->
						<div class="wl-email-wrapper close-wrapper active">
							<div>
								<div class="wl-pydetail-title">1. Your  Email <span class="edit-form">Edit</span></div>
								<div class="wl-email-input">
									<input type="email" name="email" placeholder="Email" required>
									<label class="wl-note-info">You will receive receipt and notifications on this email address.</label>
								</div>
								<div class="wl-payment-nextstep next">Continue</div>
							</div>
						</div>
						<!--Contribution container-->
						<div class="wl-contribution-wrapper close-wrapper">
							<div>
								<div class="wl-pydetail-title">2. Your  Contribution <span class="edit-form">Edit</span></div>
								<div class="wl-contribution-input">
									<label class="wl-note-info">Please see the chart to figure out your tuition amount.</label>
									<div>
										<?php
										$x = 1;
										foreach($all_fees as $all_fee) {
											foreach($all_fee as $key => $value) {
											?>	
											<div class="wl-cont-radio">
												<label class="radio-container"><?php echo $value; ?>
													<input type="radio" name="radio" class="radio" <?php if($x == 1) { echo 'checked="checked"'; } ?> value="<?php echo preg_replace('/[^0-9.]+/', '', $value); ?>">
													<span class="radio-checkmark"></span>
												</label>
											</div>
											<?php 
											$x++;
											}
										}
										?>
										<div>
											<label class="radio-container">
												<input type="radio" name="radio" class="radio">
												<span class="radio-checkmark other"></span>
											</label>
											<input type="number" name="other-radio" class="other-radio" placeholder="Other amount">
										</div>
									</div>
								</div>
								<div class="wl-payment-nextstep next">Continue</div>
							</div>
						</div>
						<!--Payment details container-->
						<div class="wl-payment-wrapper close-wrapper">
							<div>
								<div class="wl-pydetail-title">3. Payment <span class="edit-form">Edit</span></div>
								<div class="wl-payment-input">
									<div id="card-element">
									  <!-- A Stripe Element will be inserted here. -->
									</div>
									<!-- Used to display form errors. -->
									<div id="card-errors" role="alert"></div>
									<label class="wl-note-info">Transactions are secure and encrypted.<label>
									
									<div>
										<div class="wl-billing-title">Billing Address</div>
										<div class="wl-billing-name field-space">
											<div><input type="text" name="fname" placeholder="First Name" required></div>
											<div><input type="text" name="lname" placeholder="Last Name" required></div>
										</div>
										<div class="wl-billing-add1 field-space">
											<input type="text" name="add1" placeholder="Address 1">
										</div>
										<div class="wl-billing-add2 field-space">
											<input type="text" name="add2" placeholder="Address 2">
										</div>
										<div class="wl-billing-country field-space">
											<select name="country" id="country">
												<option value="usd" selected>United State</option>
												<option value="inr">India</option>
											</select>
										</div>
										<div class="wl-billing-zcs field-space">
											<div><input type="number" name="zipcode" placeholder="Zip Code"></div>
											<div><input type="text" name="city" placeholder="City"></div>
											<div><input type="text" name="state" placeholder="State"></div>
										</div>
										<div class="wl-billing-phone field-space">
											<input type="number" name="phone" placeholder="Phone Number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" required>
										</div>
										<div class="wl-billing-error field-space">Unamble to process your payment.</div>
									</div>
								</div>
								<div class="wl-payment-nextstep"><button>Continue</button></div>
							</div>
						</div>
						<!--Review & donate container-->
						<div class="wl-review-wrapper close-wrapper">
							<div>
								<div class="wl-pydetail-title">4. Review & Donate</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<script>
	jQuery(document).ready(function(){
		//open payment popup
		jQuery('.wl-fee-pay-btn').on('click', function(){
			jQuery('.wl-stripe-popup').show();
		});
		//close payment popup
		jQuery('.wl-checkout-close').on('click', function(){
			jQuery('.wl-stripe-popup').hide();
		});
		
		//next step action
		jQuery('.wl-payment-nextstep.next').on('click', function(){
			var $parent = jQuery(this).closest('.close-wrapper');
			$parent.animate( {"height": "65px" } );
			jQuery('.close-wrapper').removeClass('active');
			$parent.find('.edit-form').show();
			$parent.next().addClass('active');
		});
		
		//edit info
		jQuery('.edit-form').on('click', function(){
			var $parent = jQuery(this).closest('.close-wrapper');
			jQuery('.close-wrapper').removeClass('active');
			$parent.addClass('active');
			$parent.find('.edit-form').hide();
		});
		
		//open step on autofocus error
		jQuery('input').on('focus', function(){
			var $parent = jQuery(this).closest('.close-wrapper');
			jQuery('.close-wrapper').removeClass('active');
			$parent.addClass('active');
			$parent.find('.edit-form').hide();
		});
		
		//check/uncheck radio button
		jQuery('.radio-checkmark').on('click', function(){
			jQuery('.wl-contribution-input .radio').attr('checked', false);
			jQuery(this).parent().find('.radio').attr('checked', true);
			
		});
		
		//remove input value if other radio selected
		jQuery('.radio-checkmark:not(.other)').on('click', function(){
			jQuery('.other-radio').val('');
		});
		
		//set other amount to radio value
		jQuery('.other-radio').on('change paste keyup', function(){
			var otheramount = jQuery(this).val();
			jQuery(this).parent().find('.radio'). attr('value', otheramount);
		});
	})
	
	// Create a Stripe client.
	var stripe = Stripe('<?php echo $public_key; ?>');

	// Create an instance of Elements.
	var elements = stripe.elements();

	// Custom styling can be passed to options when creating an Element.
	// (Note that this demo uses a wider set of styles than the guide below.)
	var style = {
	  base: {
		color: '#32325d',
		fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
		fontSmoothing: 'antialiased',
		fontSize: '16px',
		'::placeholder': {
		  color: '#aab7c4'
		}
	  },
	  invalid: {
		color: '#fa755a',
		iconColor: '#fa755a'
	  }
	};

	// Create an instance of the card Element.
	var card = elements.create('card', {style: style});

	// Add an instance of the card Element into the `card-element` <div>.
	card.mount('#card-element');

	// Handle real-time validation errors from the card Element.
	card.on('change', function(event) {
	  var displayError = document.getElementById('card-errors');
	  if (event.error) {
		displayError.textContent = event.error.message;
	  } else {
		displayError.textContent = '';
	  }
	});
	
	// Handle form submission.
	var form = document.getElementById('payment-form');
	form.addEventListener('submit', function(event) {
		event.preventDefault();

		stripe.createToken(card).then(function(result) {
		if (result.error) {
		  // Inform the user if there was an error.
		  var errorElement = document.getElementById('card-errors');
		  errorElement.textContent = result.error.message;
		} else {
		  // Send the token to your server.
		  stripeTokenHandler(result.token);
		}
		});
	});
	
	// Submit the form with the token ID.
	function stripeTokenHandler(token) {
		// Insert the token ID into the form so it gets submitted to the server
		var form = document.getElementById('payment-form');
		var hiddenInput = document.createElement('input');
		hiddenInput.setAttribute('type', 'hidden');
		hiddenInput.setAttribute('name', 'stripeToken');
		hiddenInput.setAttribute('value', token.id);
		form.appendChild(hiddenInput);

		// Submit the form
		form.submit();
	}
	</script>
	<?php
	
	return ob_get_clean();
}
add_shortcode('woodlake_payment', 'woodlake_payment_shortcode');


function woodlake_submit_stripe() {
//check whether stripe token is not empty
	if(!empty($_POST['stripeToken'])){
		global $wpdb;
		$table = WOODLAKE_CUSTOMER_TBL;
		$token  = $_POST['stripeToken'];
		$email = $_POST['email'];
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];		
		$fee = $_POST['radio'];
		$address1 = $_POST['add1'];
		$address2 = $_POST['add2'];
		$address = $address1.', '.$address2;
		$country = $_POST['country'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$zipcode = $_POST['zipcode'];
		$phone = $_POST['phone'];
		$customer_id; $customer;
		
		//get customer id from the database
		$result = $wpdb->get_var("SELECT customer_id FROM $table where email = '".$email."' limit 0,1 ");
		
		if ( empty( $result ) || is_wp_error( $result ) ) {
			$customer = \Stripe\Customer::create(array( //create customer
				'source'   => $token,
				'description' => 'Woodlake Fees',
				'email' => $email,
			));
			$customer_id = $customer->id;
		} else {
			$customer_id = $result;
		}
		
		try{
		//charge a credit or a debit card
		$charge = \Stripe\Charge::create(array(
			'customer' => $customer_id,
			'amount'   => $fee*100,
			'currency' => $country,
			'description' => 'Woodlake Fees',
			'receipt_email' => $email,
			'metadata' => array(
				'First Name' => $fname,
				'Last Name' => $lname,
				'Email' => $email,
				'Fee' => $fee,
				'address' => $address,
				'city' => $city,
				'state' => $state,
				'zipcode' => $zipcode,
				'phone' => $phone,
			)
		));
		} catch (Stripe_CardError $e) {
			$errstatus = $e->getHttpStatus();
			echo 'Status is:' . $errstatus;
		} catch (Exception $e) {
			$errstatus = $e->getHttpStatus();
			echo 'Status is:' . $errstatus;			
		}
		
		//retrieve charge details
		$chargeJson = $charge->jsonSerialize();
		//check whether the charge is successful
		if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1){
			//order details
			$amount = $chargeJson['amount']/100;
			$balance_transaction = $chargeJson['balance_transaction'];
			$currency = $chargeJson['currency'];
			$status = $chargeJson['status'];
			$date = date("Y-m-d H:i:s");
			$charge_id =  $charge->id;
			$fdate = date("F j, Y");

			//insert tansaction data into the database
			$data = array(
				'customer_id' => $customer_id,
				'order_id' => $charge_id,
				'email' => $email,
				'fname' => $fname,
				'lname' => $lname,
				'fee' => $fee,
				'address' => $address,
				'country' => $country,
				'city' => $city,
				'state' => $state,
				'zipcode' => $zipcode,
				'phone' => $phone,
				'created_date' => $date
			);
						
			//add data into database			
			$iserror = $wpdb->insert($table,$data,$format = null);
			$last_insert_id = $wpdb->insert_id;
			
			//send email to user
			$to = $email;
			$subject = "Confirmation of fee payment";
			$headers = "From: abc@gmail.com \r\n";
			$headers .= "Reply-To: abc@gmail.com \r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			
			$message = '<html><body>';
			$message .= '<h2 style="color:#222;">Thank You</h2>';
			$message .=  '<p style="color:#000;font-size:16px;"><span style="text-transform: capitalize;">Dear <b>'.$fname.' '.$lname.'</b></span>,</p>';
			$message .=  '<p style="color:#ff3333;font-size:16px;">Thank you for your generous contribution of $'.$fee.', made on '.$fdate.'.</p>';
			$message .=  '<br><p style="color:#ff3333;font-size:16px;">Regards</p>';
			$message .= '</body></html>';

			//Here put your Validation and send mail
			$sent = wp_mail($to, $subject, $message, $headers);

		}else{
			
		}
	}
}
add_action('init', 'woodlake_submit_stripe');